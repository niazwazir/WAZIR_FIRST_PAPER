import os
import cv2
import h5py
import numpy
from PIL import Image
import prepare_data as pd
from keras.models import Model
import matplotlib.pyplot as plt
from keras.optimizers import adam
from keras.layers.merge import concatenate, add
from keras.layers import Conv2D, Input, Conv2DTranspose, Activation

def model_AYE():
    _input = Input(shape=(None, None, 1), name='INPUT_LR_IMAGE')
    
    #FIRST LAYER IS USED TO EXTRACT THE FEATURES
    C1 = Conv2D(filters=64, kernel_size=(3, 3), strides=(1, 1), padding='same', activation='relu',name='FIRST_LAYER')(_input)
    
    #UPSAMPLING LAYER
    U = Conv2DTranspose(filters=4, kernel_size=(14, 14), strides=(2, 2),padding='same', activation='relu',name='UPSCALE_LAYER')(C1)
     
    # ****BLOCK1***********
    MAIN_NODE_1 = Conv2D(filters=16, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu',name='MAIN_NODE_1')(U)
    
    
    Branch1a = Conv2D(filters=16, kernel_size=(1, 1), strides=(1, 1),padding='same', activation='relu',name='BRANCH_1a')(MAIN_NODE_1)
    Branch1b = Conv2D(filters=16, kernel_size=(3, 3), strides=(1, 1),padding='same', activation='relu',name='BRANCH_1b')(MAIN_NODE_1)
    Branch1c = Conv2D(filters=16, kernel_size=(5,5), strides=(1, 1),padding='same', activation='relu',name='BRANCH_1c')(MAIN_NODE_1)
    
    
    # ****CONCATENATION NODE***********
    Concatenate1 = concatenate(inputs=[Branch1a, Branch1b, Branch1c])
    out1 = Conv2D(filters=1, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu',name='OUTPUT_LAYER_1')(Concatenate1)
    
    
    # ****BLOCK2***********
    MAIN_NODE_2 = Conv2D(filters=16, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu',name='MAIN_NODE_2')(out1)
    
    
    Branch2a = Conv2D(filters=16, kernel_size=(1, 1), strides=(1, 1),padding='same', activation='relu',name='BRANCH_2a')(MAIN_NODE_2)
    Branch2b = Conv2D(filters=16, kernel_size=(3, 3), strides=(1, 1),padding='same', activation='relu',name='BRANCH_2b')(MAIN_NODE_2)
    Branch2c = Conv2D(filters=16, kernel_size=(5,5), strides=(1, 1),padding='same', activation='relu',name='BRANCH_2c')(MAIN_NODE_2)
    
    
    # ****CONCATENATION NODE***********
    Concatenate2 = concatenate(inputs=[Branch2a, Branch2b, Branch2c])
    out2 = Conv2D(filters=1, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu',name='OUTPUT_LAYER_2')(Concatenate2)
        
    model = Model(input=_input, output=out2)

    return model

def AYE_train():
	AYE = model_AYE()
	AYE.compile(optimizer=adam(lr=0.0003), loss='mse')
	#data, label = pd.read_training_data("AYE_TRAINING_FILE.h5")
	#AYE.fit(data, label, batch_size=128, epochs=20)
	#AYE.save_weights("AYE_MODEL_SCALE_2_TESTING_FILE.h5")

def AYE_predict():
	AYE = model_AYE()
	AYE.load_weights("AYE_MODEL_SCALE_2_TESTING_FILE.h5")
	IMG_NAME = "baby_GT.png"
	INPUT_NAME = "INPUT_LOW_RESOLUTION_IMAGE.png"
	OUTPUT_NAME = "MODEL_OUTPUT_IMAGE.png"

	import cv2
	img = cv2.imread(IMG_NAME)
	shape = img.shape
	img = cv2.resize(img, (shape[1] // 2, shape[0] // 2), cv2.INTER_CUBIC)
	cv2.imwrite(INPUT_NAME, img)

	img = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
	Y = numpy.zeros((1, img.shape[0], img.shape[1], 1))
	Y[0, :, :, 0] = img[:, :, 0]
	img = cv2.resize(img, (shape[1], shape[0]), cv2.INTER_CUBIC)

	pre = AYE.predict(Y, batch_size=1)
	pre[pre[:] > 255] = 255
	pre = pre.astype(numpy.uint8)
	img[:, :, 0] = pre[0, :, :, 0]
	img = cv2.cvtColor(img, cv2.COLOR_YCrCb2BGR)
	cv2.imwrite(OUTPUT_NAME, img)

	# psnr calculation:
	im1 = cv2.imread(IMG_NAME, cv2.IMREAD_COLOR)
	im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2YCrCb)

	im2 = cv2.imread(OUTPUT_NAME, cv2.IMREAD_COLOR)
	im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2YCrCb)

	print ("AYE_MODEL:")
	print (cv2.PSNR(im1, im2))

if __name__ == "__main__":
	AYE_train()
	AYE_predict()