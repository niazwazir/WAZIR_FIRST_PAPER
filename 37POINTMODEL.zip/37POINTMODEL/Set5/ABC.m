

 
 
 
 
 
 % 'nearest', ...
 'bilinear','bicubic'
figure
subplot(1,2,1),imagesc(I),axis image
title('Original','FontSize',18)
subplot(1,2,2),imagesc(I2),axis image
title('NN interpolator','FontSize',18)
colormap(gray)
print -djpeg eye_ori_NN.jpg