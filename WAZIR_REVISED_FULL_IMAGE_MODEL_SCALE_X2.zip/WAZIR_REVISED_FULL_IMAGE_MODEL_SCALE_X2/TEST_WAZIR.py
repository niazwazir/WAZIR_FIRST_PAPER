import cv2
from PIL import Image
import numpy as numpy
from keras.models import Model
from keras.optimizers import adam
from keras.layers.merge import concatenate, add
from keras.layers import Conv2D, Input, Conv2DTranspose, Activation


scale = 2

def Res_block():
    _input = Input(shape=(None, None, 64))

    conv = Conv2D(filters=64, kernel_size=(3, 3), strides=(1, 1), padding='same', activation='relu')(_input)
    conv = Conv2D(filters=64, kernel_size=(3, 3), strides=(1, 1), padding='same', activation='linear')(conv)

    out = add(inputs=[_input, conv])
    out = Activation('relu')(out)

    model = Model(inputs=_input, outputs=out)

    return model


def model_WAZIR():
    _input = Input(shape=(None, None, 1), name='input')

    Feature = Conv2D(filters=64, kernel_size=(3, 3), strides=(1, 1), padding='same', activation='relu')(_input)
    Feature_out = Res_block()(Feature)

    #Upsampling
    Upsampling1 = Conv2D(filters=4, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu')(Feature_out)
    Upsampling2 = Conv2DTranspose(filters=4, kernel_size=(14, 14), strides=(2, 2),
                                  padding='same', activation='relu')(Upsampling1)

                           
    Upsampling3 = Conv2D(filters=64, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu')(Upsampling2)

    

    # Mulyi-scale Reconstruction
    Reslayer1 = Res_block()(Upsampling3)

    Reslayer2 = Res_block()(Reslayer1)

    # ***************//
    Multi_scale1 = Conv2D(filters=16, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu')(Reslayer2)

    Multi_scale2a = Conv2D(filters=16, kernel_size=(1, 1), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale1)

    Multi_scale2b = Conv2D(filters=16, kernel_size=(1, 3), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale1)
    Multi_scale2b = Conv2D(filters=16, kernel_size=(3, 1), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale2b)

    Multi_scale2c = Conv2D(filters=16, kernel_size=(1, 3), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale1)
    Multi_scale2c = Conv2D(filters=16, kernel_size=(3, 1), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale2c)

    Multi_scale2d = Conv2D(filters=16, kernel_size=(1, 7), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale1)
    Multi_scale2d = Conv2D(filters=16, kernel_size=(7, 1), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale2d)

    Multi_scale2e = Conv2D(filters=16, kernel_size=(1,7), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale2d)

    Multi_scale2f = Conv2D(filters=16, kernel_size=(7,1), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale2e)

    Multi_scale2g = Conv2D(filters=16, kernel_size=(1,9), strides=(1, 1),
                           padding='same', activation='relu')(Multi_scale2f)

    Multi_scale2 = concatenate(inputs=[Multi_scale2a, Multi_scale2b, Multi_scale2c, Multi_scale2d,Multi_scale2e, Multi_scale2f, Multi_scale2g])

    out = Conv2D(filters=1, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu')(Multi_scale2)
    model = Model(input=_input, output=out)

    return model


def WAZIR_train():
    WAZIR = model_WAZIR()
    WAZIR.compile(optimizer=adam(lr=0.0003), loss='mse')
    #WAZIR.summary()
    #data, label = pd.read_training_data("./ABC.h5")
    #WAZIR.fit(data, label, batch_size=56, nb_epoch=1)
    #WAZIR.save_weights("WAZIR_MODEL_SCALE_2A.h5")


def WAZIR_predict():
    WAZIR = model_WAZIR()
    WAZIR.load_weights("WAZIR_MODEL_SCALE_2.h5")
    IMG_NAME = "Set5/butterfly_GT.bmp"###########################################################################################################################
    INPUT_NAME = "INPUT_LOW_RESOLUTION_IMAGE.png"
    OUTPUT_NAME = "MODEL_OUTPUT_IMAGE.png"

    import cv2
    img = cv2.imread(IMG_NAME)
    shape = img.shape
    img = cv2.resize(img, (shape[1] // 2, shape[0] // 2), cv2.INTER_CUBIC)
    cv2.imwrite(INPUT_NAME, img)

    img = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
    Y = numpy.zeros((1, img.shape[0], img.shape[1], 1))
    Y[0, :, :, 0] = img[:, :, 0]
    img = cv2.resize(img, (shape[1], shape[0]), cv2.INTER_CUBIC)

    pre = WAZIR.predict(Y, batch_size=1)
    pre[pre[:] > 255] = 255
    pre = pre.astype(numpy.uint8)
    img[:, :, 0] = pre[0, :, :, 0]
    img = cv2.cvtColor(img, cv2.COLOR_YCrCb2BGR)
    cv2.imwrite(OUTPUT_NAME, img)

    # psnr calculation:
    im1 = cv2.imread(IMG_NAME, cv2.IMREAD_COLOR)
    im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2YCrCb)
    im2 = cv2.imread(INPUT_NAME, cv2.IMREAD_COLOR)
    im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2YCrCb)
    im2 = cv2.resize(im2, (img.shape[1], img.shape[0]))
    im3 = cv2.imread(OUTPUT_NAME, cv2.IMREAD_COLOR)
    im3 = cv2.cvtColor(im3, cv2.COLOR_BGR2YCrCb)

    


if __name__ == "__main__":
    WAZIR_train()
    WAZIR_predict()


Bicubic = cv2.imread('INPUT_LOW_RESOLUTION_IMAGE.png',cv2.IMREAD_COLOR)
#bicubic_img = cv2.resize(Bicubic,None, fx = scale, fy = scale, interpolation = cv2.INTER_CUBIC)
nearest_img = cv2.resize(Bicubic,None, fx = scale, fy = scale, interpolation = cv2.INTER_NEAREST)
#cv2.imwrite('bicubic.png',bicubic_img)
cv2.imwrite('nearest.png',nearest_img)



img2 = cv2.imread('INPUT_LOW_RESOLUTION_IMAGE.png', cv2.IMREAD_UNCHANGED)
cv2.imshow('2X_LRIMAGE',img2)

#img3 = cv2.imread('bicubic.png', cv2.IMREAD_UNCHANGED)
#cv2.imshow('BICUBIC_UPSCALE_IMAGE',img3)

img4 = cv2.imread('nearest.png', cv2.IMREAD_UNCHANGED)
cv2.imshow('INTERPOLATION_UPSCALE_IMAGE',img4)


img5 = cv2.imread('MODEL_OUTPUT_IMAGE.png', cv2.IMREAD_UNCHANGED)
cv2.imshow('WAZIR_MODEL_IMAGE',img5)

cv2.waitKey(0) #image will not show until this is called
cv2.destroyAllWindows() #make sure window closes cleanly